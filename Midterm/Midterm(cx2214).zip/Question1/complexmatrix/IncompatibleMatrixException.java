package complexmatrix;

public class IncompatibleMatrixException extends Exception{
    public IncompatibleMatrixException() {
        super("Matrix Incompatible");
    }
}
